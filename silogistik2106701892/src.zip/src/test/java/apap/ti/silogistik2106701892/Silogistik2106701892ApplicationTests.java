package apap.ti.silogistik2106701892;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Silogistik2106701892ApplicationTests {

	@Test
	void contextLoads() {
	}

}
